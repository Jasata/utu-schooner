#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# config.py - Schooner local agent settings and constants.
#   2021-09-19  Initial version.
#
# Apparently "settings.py" causes issues...
#
import os
import logging

PORT            = 8080
LOG_LEVEL       = logging.DEBUG
SERVER_URL      = "https://schooner.utu.fi/"
DOWNLOAD_URL    = f"{SERVER_URL}exercise"
LOCALTMP        = os.path.join(os.path.expanduser("~"), ".schooner/downloads")
SQLITE3_FILE    = os.path.join(os.path.expanduser("~"), ".schooner/schooner-local-agent.sqlite3")