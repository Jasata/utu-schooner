#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# schooner-local-agent.py - Schooner assistant vm local server.
#   2021-09-19  Initial version.
#   2021-09-20  Clean-ups.
#
#
# Schooner site redirects assistant browser to load an URL from this server
# when a new submission is taken under evaluation. The URL's query parameter
# has a time-limited access token, which this local server passes back to the
# Schooner server via an endpoint which does not require SSO authentication.
#
# If the token is valid (registered and not expired), the endpoint sends the
# exercise as an .tar.gz archive, along with relevant IDs in the HTTP header.
#
# This local server extracts the submission, moves it to MPLAB X's project
# directory, and modifies project files so that when the MPLAB X IDE starts,
# the student submission appears in the list of projects, named as:
#
#   {assignment_id}-{student_uid}
#
# Once the extraction and IDE configuration is complete, this local server will
# redirect the browser back to Schooner server, into the submission evaluation
# form.
#
import os
import sys
import logging
from http.server    import HTTPServer, BaseHTTPRequestHandler
from urllib.parse   import urlparse, parse_qs

import config
from MPLABX         import MPLABX, MPLABXProject, MPLABXProjectUIProperties
from RequestHandler import RequestHandler





#
# Sanity - Check / create locations
#
if not os.path.isdir(MPLABX.projects_path):
    raise Exception(
        f"MPLAB X project directory '{MPLABX.projects_path}' does not exist!"
    )





if __name__ == "__main__":

    #
    # Set up logging
    #
    if os.isatty(sys.stdin.fileno()):
        # Executed from terminal
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter('[%(levelname)s] %(message)s')
        )
    else:
        # Executed as daemon
        handler = logging.handlers.SysLogHandler(address = '/dev/log')
        handler.setFormatter(
            logging.Formatter('%(name)s: [%(levelname)s] %(message)s')
        )

    logging.basicConfig(
        handlers    = [handler],
        level       = config.LOG_LEVEL
    )

    log = logging.getLogger(__file__)
    # Eitherway, DB log handler is always added
    #handler = LogDBHandler(cfg.database, level = cfg.loglevel)
    #log.addHandler(handler)


    #
    # Create and start localhost HTTP server
    #
    httpd = HTTPServer(('', config.PORT), RequestHandler)
    log.info(f"Schooner local agent serving on port {config.PORT}")
    httpd.serve_forever()
    log.info("Schooner local agent exists")


# EOF
