#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# database.py - Schooner local agent database module.
#   2021-09-19  Initial version.
#
#
import sqlite3
import config


TBL_EXISTS = """
SELECT      COUNT(name)
FROM        sqlite_master
WHERE       type = 'table'
            AND
            name = 'submission'
"""
TBL_CREATE = """
CREATE TABLE submission (
    submission_id   TEXT PRIMARY KEY,
    course_id       TEXT,
    assignment_id   TEXT,
    uid             TEXT,
    path            TEXT,
    created         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
"""
UPSERT = """
INSERT INTO submission (
    submission_id,
    course_id,
    assignment_id,
    uid,
    path
)
VALUES
(
    :sid,
    :cid,
    :aid,
    :uid,
    :path
)
ON CONFLICT (submission_id) DO
    UPDATE
    SET     course_id       = excluded.course_id,
            assignment_id   = excluded.assignment_id,
            uid             = excluded.uid,
            path            = excluded.path
    WHERE   excluded.submission_id = submission.submission_id
"""
SELECT = """
SELECT      *
FROM        submission
WHERE       submission_id = :sid
"""
DELETE = """
DELETE
FROM        submission
WHERE       submission_id = :sid
"""


#
# Initialize only once
#
if 'connection' not in locals():
    connection = sqlite3.connect(config.SQLITE3_FILE)
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()
    # Ensure the table exists
    cursor.execute(TBL_EXISTS)
    if cursor.fetchone()[0] != 1:
        cursor.execute(TBL_CREATE)


def add(cid, aid, uid, sid, path):
    cursor.execute(UPSERT, locals())
    cursor.connection.commit()


def remove(sid):
    cursor.execute(DELETE, locals())
    cursor.connection.commit()


def get(sid):
    rec = cursor.execute(SELECT, locals()).fetchone()
    return dict(rec) if rec else None



""" OBSOLETED VERSION
class SQLite3():

    def __init__(self, file = 'schooner-local-agent.sqlite3'):
        self.file = file
        with sqlite3.connect(self.file).cursor() as cursor:
            cursor.execute(TBL_EXISTS)
            if cursor.fetchone()[0] != 1:
                cursor.execute(TBL_CREATE)

    def __enter__(self):
        self.conn = sqlite3.connect(self.file)
        self.conn.row_factory = sqlite3.Row
        return self.conn.cursor()

    def __exit__(self, type, value, traceback):
        self.conn.commit()
        self.conn.close()
"""
