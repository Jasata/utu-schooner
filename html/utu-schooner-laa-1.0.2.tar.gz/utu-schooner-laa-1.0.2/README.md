# Local Assistant Agent for Schooner

Solution to download student submissions from the Schooner server (using a time-limited access token). After downloading the archive, it is extracted and it's folder renamed (currently: "{assignment id}-{student uid}.X") and moved to MPLAB X's projects directory. It's display name also changed (same as folder name minus the ".X"). Finally, MPLAB X configuration file is modified so that when the IDE starts, it will display this new project in the projects list and it is set as the active project (compile icon will compile this project, not some else).

Local agent also has an endpoint for removing the student submission.

For semester 2021-2022, local agent deals with only MPLAB X submissions. To support other tools (Eclipse, Visual Studio Code, etc.), this solution needs to be restructured so that various other tools and the methods to deliver student submissions to them can be used based on the information provided by the Schooner server (HTTP headers of the download response).

## MPLAB X project structure:

According to [MPLAB X FAQ](https://microchipdeveloper.com/faq:72), only souces, headers, and `Makefile` are needed from the project folder root. In addition, subfolder `nbproject` and two XML files from therein are required:

```bash
dtek@dtek:~/MPLABXProjects/E01-BlinkLed.X$ tree .
.
├── main.c                                              [1]
├── Makefile                                            [2]
└── nbproject                                           (possibly "net beans project" ?)
    ├── configurations.xml                              [3]
    ├── Makefile-default.mk                             IGNORED
    ├── Makefile-genesis.properties                     IGNORED
    ├── Makefile-impl.mk                                IGNORED
    ├── Makefile-local-default.mk                       IGNORED
    ├── Makefile-variables.mk                           IGNORED
    ├── Package-default.bash                            IGNORED
    ├── private                                         IGNORED
    │   ├── configurations.xml                          IGNORED
    │   └── private.xml                                 IGNORED
    └── project.xml                                     [4]

2 directories, 12 files
```
[1]     Source file  
[2]     GNU Makefile, includes `nbproject/Makefile-impl.mk` and `nbproject/Makefile-variables.mk`, which both are automatically generated  
[3]     Project configuration. Folder structure showin in the IDE, selected chip, used compiler... everything.  
[4]     **Contains project (display) name.** Needs to be changed in the assistant virtual machines, or otherwise there are dozens of identically named projects.

## How to add project directory into MPLAB X

Simply copying a project directory to `~/MPLABXProjects` will **NOT** make the IDE include it in the projects view (even when restarted). What is shown, is dictated by `projectui.properties` file:

    ~/.mplab_ide/dev/v5.45/config/Preferences/org/netbeans/modules/projectui.properties

The file has three key-value pairs for each project (_note the incremental number suffix in the keys_):
- `openProjectsDisplayNames.0=<name shown in the list>`
- `openProjectsIcons.0=<base64 encoded Java icon>`
- `openProjectsURLs.0=file:/home/dtek/MPLABXProjects/test_program.X/`

These three keys need to be added, with the next incremental suffix number, for the MPLAB X to start up displaying the new project in the project list.

## How to set active project in MPLAB X

Within the same `projectui.properties` (see above) a key-value pair exists for setting the active project:

    mainProjectURL=file:/home/dtek/MPLABXProjects/test_program.X/

**IMPORTANT:** The path **MUST** end with "`/`", or this setting has no effect in the IDE!

## Start-up with open file

One of the _very_ few command line options of MPLAB X allow opening a file (or files), even specifying line position for the cursor:

    mplab_ide --open file1[:line1]...

For example:

    mplab_ide --open ~/MPLABXProjects/test_program.X/main.c:30 &


## Source Encoding
This is a project-setting, found in `nbproject/project.xml` (project properties > General, at the bottom part of the dialog). MPLAB X's default encoding is ISO-8859-1. Preferrable would of course be UTF-8, but isn't necessarily something that must be changed.

**Semester 2021-2022 does not concern itself with encoding - but it may become necessary when testing automation is built.**

# Assistant VM modifications

Assistan vm is always based on the student vm, only modified / installed with additional tools.

- Change conky header from "Embedded (2021-2022)" to "Embedded Asssistant (2021-2022).
- Add https://schooner.utu.fi/assistant.html shortcut to Desktop.
- Download local agent from: [https://schooner.utu.fi/utu-schooner-laa-1.0.2.tar.gz](https://schooner.utu.fi/utu-schooner-laa-1.0.2.tar.gz)
- Extract and execute `./utu-schooner-laa-1.0.2/install.py`
- Execute `./utu-schooner-laa-1.0.2/xtra/install.py`
 

# Systemd service

Start / stop:

    systemctl [start | stop] schooner-local-agent.service

Enable / disable (automatic start on boot):

    systemctl [enable | disable] schooner-local-agent.service

Status check:

    systemctrl status schooner-local-agent.service

See service logs:

    journalctl -u schooner-local-agent.service

Clear logs:

    journalctl --rotate
    journalctl --vacuum-time=1s