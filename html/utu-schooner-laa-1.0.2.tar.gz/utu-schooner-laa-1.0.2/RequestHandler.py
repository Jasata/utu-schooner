#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# RequestHandler.py - Extended BaseHTTPRequestHandler
#   2021-09-19  Initial version.
#
import os
import re
import json
import shutil
import requests
import logging

from http.server    import BaseHTTPRequestHandler
from urllib.parse   import urlparse, parse_qs
from MPLABX         import MPLABX, MPLABXProject, MPLABXProjectUIProperties
import config
import database


#
# logger for module
#
log = logging.getLogger(__name__)


#
# Ensure that the local tmp exists
#
if not os.path.isdir(config.LOCALTMP):
    log.debug(f"Creating local temp directory '{config.LOCALTMP}'")
    os.makedirs(config.LOCALTMP, exist_ok=True)


HTML_SID_MISSING = """
<!DOCTYPE html>
<html>
  <head>
    <title>Missing SID</title>
  </head>
  <body>
    <h1>Request did not specify access sid (submission id)!</h1>
    <p>
    Service cannot complete the requested action without the submission id.
    </p>
  </body>
</html>
"""
HTML_TOKEN_MISSING = """
<!DOCTYPE html>
<html>
  <head>
    <title>Missing Access Token</title>
  </head>
  <body>
    <h1>Request did not specify access token!</h1>
    <p>
    Service cannot complete the requested action without the access token.
    </p>
  </body>
</html>
"""


def report() -> str:
    return """<!DOCTYPE html>
<html>
  <head>
    <title>Nothing to report!</title>
  </head>
  <body>
    <h1>Nothing to report</h1>
  </body>
</html>
    """

def malformed(sid: str, token: str) -> str:
    return f"""<!DOCTYPE html>
<html>
  <head>
    <title>Malforned submission!</title>
  </head>
  <body>
    <h2>Submission #{sid} is not a valid MPLAB X project directory!</h2>
    <b>Process of downloading and extracting the exercise was not successful!</b><br>
    Please download the exercise manually from
    <a href="{config.DOWNLOAD_URL}?token={token}">{config.DOWNLOAD_URL}?token={token}</a>
    and extract it to '{MPLABX.projects_path}'<br>
    <br>
    Return to the submission evaluation: <a href="{config.SERVER_URL}">{config.SERVER_URL}</a>
    """


def download(url: str, dest_folder: str):
    """Download and save file, return headers dictionary with the saved file injected as 'X-Archive'"""
    # According to RFC 7230, HTTP Header names are case-insensitive.
    # requests.Response.headers is a special case-insensitive dictionary 

    #filename = url.split('/')[-1].replace(" ", "_")  # be careful with file names
    #file_path = os.path.join(dest_folder, filename)

    req = requests.get(url, stream = True)
    if req.ok:
        fname = re.findall("filename=(.+)", req.headers['content-disposition'])[0]
        log.debug(f"Received file by name: '{fname}'")
        fpath = os.path.join(dest_folder, fname)
        try:
            # Delete, if exists
            os.unlink(fpath)
        except:
            pass
        # inject to headers
        req.headers['X-Archive'] = fpath
        log.debug(f"Saving to '{os.path.abspath(fpath)}'")
        with open(fpath, 'wb') as f:
            for chunk in req.iter_content(chunk_size = 1024 * 1024):
                if chunk:
                    f.write(chunk)
                    f.flush()
                    os.fsync(f.fileno())
        return req.headers
    else:  # HTTP status code 4XX/5XX
        raise Exception(
            f"Download failed: status code {req.status_code}\n{req.text}"
        )


def remove(sid: str):
    """Removes student project folder from MPLAB X."""
    rec = database.get(sid)
    # If query does not return row(s), rec will be None
    if not rec:
        # It's not in the database, just return
        log.warning(f"Submission #{sid} not found in database!")
        return
    else:
        database.remove(sid)

    #log.debug(str(dict(rec)))
    if rec['path']:
        shutil.rmtree(rec['path'])
        with MPLABXProjectUIProperties(MPLABX.projectxml_path) as projectxml:
            log.debug(f"Removing '{os.path.split(rec['path'])[1]}' from '{MPLABX.projectxml_path}'")
            projectxml.remove(os.path.split(rec['path'])[1])
        log.info(f"REMOVE submission #{sid} ('{os.path.split(rec['path'])[1]}')")
    else:
        log.info(f"REMOVE submission #{sid} (no path available)")
    return





def fetch(token: str) -> str:
    import gzip
    import tarfile
    import cgi
    import urllib.request
    url = f"{config.DOWNLOAD_URL}?token={token}"
    hdr = download(url, config.LOCALTMP)

    #
    # Unzip
    #
    gzfilename  = hdr.get('X-Archive', None)
    tarfilename = gzfilename.rsplit(".", 1)[0]
    try:
        os.unlink(tarfilename)
    except:
        pass
    with    gzip.open(gzfilename, 'rb') as fgz, \
            open(tarfilename, 'wb') as ftar:
        shutil.copyfileobj(fgz, ftar)
    os.unlink(gzfilename)

    #
    # Extract tar (archive will ALWAYS have 'accepted' directory)
    #
    srcdir  = os.path.join(config.LOCALTMP, "accepted")
    try:
        shutil.rmtree(srcdir)
    except:
        pass
    with tarfile.open(tarfilename) as ftar:
        ftar.extractall(config.LOCALTMP)
    os.unlink(tarfilename)

    #
    # Move project folder to MPLAB X projects directory
    #
    cid     = hdr['X-CourseID']
    aid     = hdr['X-AssignmentID']
    uid     = hdr['X-UserID']
    sid     = hdr['X-SubmissionID']


    with MPLABXProjectUIProperties(MPLABX.projectxml_path) as projectxml:

        path = None
        try:
            project = MPLABXProject(srcdir, uid, aid)
            path = project.deploypath
            log.debug(f"{project.name} Will be deployed as {project.deployfolder}")
            # Set project name to match {aid}-{uid}
            project.name = project.deployfolder[:-2]
            log.debug(f"Project name: '{project.name}'")
            project.deploy()
            # Add the project folder to IDE's project.xml
            projectxml.add(project)
            #
            # Start MPLAB X
            #
            log.info("MPLAB X automatic start not implemented")
            # Cannot attach to the window manager...
            #log.debug(f"/usr/bin/mplab_ide --open {project.deploypath}/main.c")
            #os.environ["DISPLAY"] = ":0.0"
            #os.spawnl(
            #    os.P_NOWAIT,
            #    "/usr/bin/mplab_ide",
            #    "--open",
            #    f"{project.deploypath}/main.c",
            #    {'DISPLAY' : ':0.0'}
            #)

        except Exception as e:
            log.error(str(e))
            return f"http://localhost:{config.PORT}/malformed?sid={sid}&token={token}"

        finally:
            #
            # Store information
            #
            database.add(cid, aid, uid, sid, path)
            log.debug(
                "Submission #{} added to database ('{}', '{}', '{}', '{}')".format(
                    sid, cid, aid, uid, path
                )
            )


    # Remove untar'ed directory
    shutil.rmtree(srcdir)

    log.info(f"FETCH submission #{sid} '{uid}' ('{os.path.split(path)[1]}')")
    return hdr.get('X-Redirect', 'https://schooner.utu.fi')









class RequestHandler(BaseHTTPRequestHandler):

    def _send_html(self, payload: str):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(payload.encode('UTF-8'))


    def _send_json(self, payload: dict):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(payload).encode('UTF-8'))


    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()


    def do_GET(self):
        # Valid URL *can* have more than one '?'
        log.debug(f"self.path = {self.path}")
        if self.path == '/favicon.ico':
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")
            return

        path, qstr = tuple(self.path.split("?", 1))
        # Dict where values are lists (even if with only one value)
        params = parse_qs(qstr)

        if path == "/fetch":
            if 'token' not in params:
                self._send_html(
                    HTML_TOKEN_MISSING
                )
            else:
                try:
                    redirect_url = fetch(params['token'][0])
                except Exception as e:
                    url = f"{config.DOWNLOAD_URL}?token={params['token'][0]}"
                    self._send_html(
                        f"""
                        <html>
                        <body>
                        <b>Process of downloading and extracting the exercise was not successful!</b><br>
                        Please download the exercise manually from <a href="{url}">{url}</a> and extract
                        it to '{MPLABX.projects_path}'<br>
                        <br>
                        Return to the submission evaluation: <a href="{config.SERVER_URL}">{config.SERVER_URL}</a>
                        <br>
                        Exception:<br>
                        {str(e)}
                        """
                    )
                else:
                    # Redirect back to schooner
                    self.send_response(302)
                    self.send_header(
                        'Location',
                        redirect_url
                    )
                    self.end_headers()

                finally:
                    return

        elif path == "/remove":
            if 'sid' not in params:
                self._send_html(
                    HTML_SID_MISSING
                )
            else:
                redirect_url = params['redirect'][0]
                log.debug(f"REDIRECTING TO {redirect_url}")
                remove(params['sid'][0])
                # Redirect back to schooner
                self.send_response(302)
                self.send_header(
                    'Location',
                    redirect_url
                )
                self.end_headers()

        elif path == "/malformed":
            self._send_html(
                malformed(
                    params.get('sid', ['(unknown)'])[0],
                    params.get('token', ['(unknown)'])[0]
                )
            )
        elif path == "/report":
            self._send_html(
                report()
            )
        else:
            # Complaint response
            self.send_response(405)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b"405 Method Not Allowed")

        return



# EOF