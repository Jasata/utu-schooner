#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# install.py - Schooner local agent installer.
#   2021-09-19  Initial version.
#
#
# Script that is intended to be execute after the local agent repository
# has been cloned into an assistant virtual machine.
#
import os
import pwd
import grp
import shutil
import subprocess

# Local used under which the local agent is installed
USER = "dtek"


class Identity():

    def __init__(self, user: str, group: str = None):
        self.uid = pwd.getpwnam(user).pw_uid
        if not group:
            self.gid = pwd.getpwnam(user).pw_gid
        else:
            self.gid = grp.getgrnam(group).gr_gid

    def __enter__(self):
        self.original_uid = os.getuid()
        self.original_gid = os.getgid()
        os.setegid(self.uid)
        os.seteuid(self.gid)

    def __exit__(self, type, value, traceback):
        os.seteuid(self.original_uid)
        os.setegid(self.original_gid)




class SubProcess:

    def __init__(
        self,
        cmd: str,
        shell: bool = False,
        stdout = subprocess.PIPE,
        stderr = subprocess.PIPE
    ):
        """If output is not wanted, set stdout/stderr = subprocess.DEVNULL."""
        self.command = cmd
        self.stdout  = ''
        self.stderr  = ''
        try:
            if not shell:
                # Set empty double-quotes as empty list item
                # Required for commands like; ssh-keygen ... -N ""
                cmd = ['' if i == '""' or i == "''" else i for i in cmd.split(" ")]
            prc = subprocess.run(
                cmd,
                shell  = shell,
                stdout = stdout,
                stderr = stderr
            )
            # Store result/output
            self.returncode = prc.returncode
            self.stdout = prc.stdout.decode("utf-8") if stdout == subprocess.PIPE else None
            self.stderr = prc.stderr.decode("utf-8") if stderr == subprocess.PIPE else None

        except Exception as e:
            self.returncode = -2
            self.stdout = ""
            self.stderr += str(e)




def getch():
    """Read single character from standard input without echo."""
    import sys, tty, termios
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch




# Python 3.6+
def yn_prompt(question: str, default=None, echo=False) -> bool:
    """Prompts a Yes/No question in console and returns True ("yes") or False ("no"). Second argument ("default") has three possible values; None, "n" or "y". Strings that cannot be interpreted are considered None. Default affects how ENTER keys are interpreted."""
    if default:
        # Empty string is False and will not branch here
        default = default[0].lower()
        if default not in ("n", "y"):
            default = None
            opts = "y/n"
        else:
            opts = ("y/N", "Y/n")[int(default == 'y')]
    else:
        default = None
        opts = "y/n"
    print(f"{question} ({opts}): ", end = "", flush = True)
    c = ""
    while c not in ("y", "n"):
        c = getch().lower()
        if ord(c) == 0x0d and default:
            selection = default == 'y'
            break
    selection = c == 'y'
    if echo:
        print(f"{('NO', 'YES')[int(selection)]}", flush = True)
    else:
        print("")
    return selection




if __name__ == '__main__':


    #
    # Prompt for confirmation
    #
    print("This installation script needs to be executed as root.")
    print(f"You are currently user '{pwd.getpwuid(os.getuid()).pw_name}'")
    if yn_prompt("Continue and install Schooner local agent?", default="NO", echo=True):
        pass
    else:
        print("Installation cancelled")
        os._exit(1)

    try:
        #
        # Change cwd to script directory
        #
        os.chdir(os.path.dirname(os.path.realpath(__file__)))


        #
        # Create directories
        #
        print("\tCreating ~/.schooner directories...", end='', flush=True)
        #installdir = os.path.join(os.path.expanduser(f"~{USER}/"), ".schooner")
        with Identity(USER, USER):
            installdir = os.path.join(
                os.path.expanduser(f"~{pwd.getpwuid(os.geteuid())[0]}/"),
                ".schooner"
            )
            os.makedirs(
                os.path.join(installdir, "downloads"),
                mode=0o700,
                exist_ok=True
            )
        print("done")


        #
        # Copy files
        #
        print("\tCopying scripts...", end='', flush=True)
        with Identity(USER, USER):
            shutil.copy2("config.py", installdir)
            shutil.copy2("database.py", installdir)
            shutil.copy2("MPLABX.py", installdir)
            shutil.copy2("RequestHandler.py", installdir)
            shutil.copy2("schooner-local-agent.py", installdir)
        print("done")

        print("\tInstalling systemd unit file to /etc/systemd/system/...", end="", flush=True)
        shutil.copy2(
            "schooner-local-agent.systemd",
            "/etc/systemd/system/schooner-local-agent.service"
        )
        print("done")

        print("\tEnabling service...", end='', flush=True)
        enable = SubProcess("systemctl enable schooner-local-agent.service")
        if enable.returncode:
            raise Exception(enable.stderr)
        print("done")

        print("\tStarting service...", end='', flush=True)
        enable = SubProcess("systemctl start schooner-local-agent.service")
        if enable.returncode:
            raise Exception(enable.stderr)
        print("done")


    except Exception as e:
        print("ERROR!")
        print(str(e))
        print("Installation failed!")

    else:
        print("Installation completed successfully!")

# EOF