# Other minor modifications

This folder contains other small modifications that turn student virtual machine into an assistant VM.

