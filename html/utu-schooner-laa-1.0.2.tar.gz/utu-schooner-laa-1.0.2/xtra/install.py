#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Schooner - Course Management System
# University of Turku / Faculty of Technilogy / Department of Computing
# (c) 2021, Jani Tammi <jasata@utu.fi>
#
# install.py - Cosmetic assistant vm configurations.
#   2021-09-20  Initial version.
#
#
import os
import pwd
import grp
import shutil

# Local used under which the local agent is installed
USER = "dtek"
DESKTOP_SCHOONER_CONTENT = """
[Desktop Entry]
Version=1.0
Type=Link
Name=Schooner
Comment=Assistant tools
Icon=Schooner.desktop-icon.png
URL=https://schooner.utu.fi/
"""



class Identity():

    def __init__(self, user: str, group: str = None):
        self.uid = pwd.getpwnam(user).pw_uid
        if not group:
            self.gid = pwd.getpwnam(user).pw_gid
        else:
            self.gid = grp.getgrnam(group).gr_gid

    def __enter__(self):
        self.original_uid = os.getuid()
        self.original_gid = os.getgid()
        os.setegid(self.uid)
        os.seteuid(self.gid)

    def __exit__(self, type, value, traceback):
        os.seteuid(self.original_uid)
        os.setegid(self.original_gid)




def yn_prompt(question: str, default=None, echo=False) -> bool:
    """Prompts a Yes/No question in console and returns True ("yes") or False ("no"). Second argument ("default") has three possible values; None, "n" or "y". Strings that cannot be interpreted are considered None. Default affects how ENTER keys are interpreted."""
    def getch():
        """Read single character from standard input without echo."""
        import sys, tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

    if default:
        # Empty string is False and will not branch here
        default = default[0].lower()
        if default not in ("n", "y"):
            default = None
            opts = "y/n"
        else:
            opts = ("y/N", "Y/n")[int(default == 'y')]
    else:
        default = None
        opts = "y/n"
    print(f"{question} ({opts}): ", end = "", flush = True)
    c = ""
    while c not in ("y", "n"):
        c = getch().lower()
        if ord(c) == 0x0d and default:
            selection = default == 'y'
            break
    selection = c == 'y'
    if echo:
        print(f"{('NO', 'YES')[int(selection)]}", flush = True)
    else:
        print("")
    return selection


if __name__ == '__main__':

    #
    # Prompt for confirmation
    #
    print("This installation script needs to be executed as root.")
    print(f"You are currently user '{pwd.getpwuid(os.getuid()).pw_name}'")
    if yn_prompt("Continue and apply assistant VM changes?", default="NO", echo=True):
        pass
    else:
        print("Installation cancelled")
        os._exit(1)

    try:
        #
        # Change cwd to script directory
        #
        os.chdir(os.path.dirname(os.path.realpath(__file__)))

        #
        # Copy files
        #
        print("\tCopying icon...", end='', flush=True)
        shutil.copy2("Schooner.desktop-icon.png", "/usr/share/icons")
        os.chmod("/usr/share/icons/Schooner.desktop-icon.png", 0x444)
        os.chown(
            "/usr/share/icons/Schooner.desktop-icon.png",
            pwd.getpwnam('root').pw_uid,
            pwd.getpwnam('root').pw_gid
        )
        print("done")

        #
        # Write .desktop shortcut
        #
        print("\tCreating desktop icon...", end="", flush=True)
        with Identity(USER, USER):
            desktop = os.path.join(
                os.path.expanduser(f"~{pwd.getpwuid(os.geteuid())[0]}/"),
                "Desktop"
            )
            shortcut = os.path.join(desktop, "schooner.utu.fi.desktop")
            with open(shortcut, "w") as file:
                file.write(DESKTOP_SCHOONER_CONTENT)
            os.chmod(shortcut, 0o744)
        print("done")


    except Exception as e:
        print("ERROR!")
        print(str(e))
        print("Installation failed!")

    else:
        print("Installation completed successfully!")
